# Daily Report Generator

Bedrock based daily factory report generator.

MVP pipeline:

```text
PrepareReportWindow
  -> AggregateFactoryHour
  -> MergeFactoryDaily
  -> GenerateFactoryReport
```

The report pipeline reads S3 `processed/` data and writes factory daily
artifacts under `reports/daily/yyyy=YYYY/mm=MM/dd=DD/{factory_id}/`.
Bedrock receives only `report-context.json`.

